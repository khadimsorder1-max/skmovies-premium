# SKMovies Fix Package (v3.3.8)

This package contains production-grade fixes for the SKMovies site at
`https://skmovies-premium.pages.dev`.

## What's inside

```
skmovies-fix/
├── README.md                  ← this file (quick-start)
├── AUDIT-REPORT.md            ← full line-by-line audit + every fix explained
├── index.html                 ← fixed HTML (v3.3.8 cache-bust, preconnect, noscript)
├── styles.css                 ← fixed CSS (backdrop-filter reduced, animations disabled)
├── app.js                     ← fixed JS (scrollLock boolean flag + 14 other fixes)
├── sw.js                      ← bumped to v3.3.8 (forces cache invalidation)
├── manifest.json              ← unchanged from v3.3.7
└── functions/
    └── api/
        ├── img/index.js       ← rewritten image proxy (browser UA + edge cache)
        └── proxy/index.js     ← rewritten CORS proxy (browser UA + host allowlist)
```

## TL;DR — what was fixed

1. **CRITICAL bug fixed:** After clicking a movie and pressing browser-back,
   the homepage used to hang (no scroll, no clicks). Root cause was a
   falsy-string check in `scrollLock.unlock()`. Fixed with an explicit
   boolean flag + defense-in-depth popstate guard.
2. **Laggy UI fixed:** Removed 15 of 17 `backdrop-filter: blur(Npx)` usages
   (the always-visible ones were the main scroll-jank cause). Reduced the
   remaining 2 from 12/16px to 6px. Disabled infinite `box-shadow` pulse
   animations. Removed `transition` on `<body>`.
3. **Image 403s fixed:** Rewrote `/api/img` to send a real `User-Agent`
   and empty `Referer`, defeating TMDB's bot protection. Added Cloudflare
   edge caching (24h TTL) so repeat visits are served from cache.
4. **12 smaller fixes:** Save-Data respect, IntersectionObserver root
   margin reduced, SW registration moved behind `window.load`, scroll rAF
   flag reset before work, popstate guards, `isSafeUrl` validation on DL
   buttons, etc.

See `AUDIT-REPORT.md` for the full line-by-line breakdown.

## Deployment (60 seconds)

1. **Backup your current code:**
   ```bash
   git clone <your-repo> skmovies-backup
   ```

2. **Copy these 5 files** from this package over your existing files:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `sw.js`
   - (`manifest.json` is unchanged — skip unless you want to.)

3. **Copy these 2 backend Functions** (if your Cloudflare Pages project
   has a `functions/` directory):
   - `functions/api/img/index.js`
   - `functions/api/proxy/index.js`
   
   If your structure uses `functions/api/img.js` (single file) instead of
   `functions/api/img/index.js` (directory), just rename/move accordingly.

4. **Commit + push:**
   ```bash
   git add -A
   git commit -m "fix: scrollLock + perf + img proxy (v3.3.8)"
   git push origin main
   ```
   Cloudflare Pages auto-deploys.

5. **Verify** with the checklist in `AUDIT-REPORT.md` §11.

## Verification (the most important test)

After deploy, do exactly this in your browser:

1. Open `https://skmovies-premium.pages.dev/`
2. Click any movie card.
3. When the movie modal opens, press the **browser back button**.
4. Back on the homepage, **scroll down** with the mouse wheel.

✅ If scrolling works → fix is live.
❌ If scrolling is still stuck → clear your browser cache / Service Worker
   (DevTools → Application → Service Workers → Unregister), then reload.

## What if something goes wrong?

The fixes are surgical and additive — no existing functionality was
removed. If anything regresses, revert the deploy and the site returns
to v3.3.7 behavior. The only file with a "breaking" change is `app.js`
(scrollLock), and that change is strictly more correct than the original.

## Need help?

Full audit report with line numbers, root-cause analysis, and live
verification evidence is in `AUDIT-REPORT.md`.
