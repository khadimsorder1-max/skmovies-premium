/* ============================================================================
   /api/proxy — Generic CORS proxy with host allowlist
   ----------------------------------------------------------------------------
   Used by app.js to fetch savelinks / fdm host pages that don't send CORS
   headers. Hosts are validated against PROXY_HOST_PATTERNS in app.js to
   prevent abuse as an open proxy.
   ============================================================================ */

const ALLOWED_PROXY_HOSTS = [
  /^dl\.freedrivemovie\.org$/i,
  /\.freedrivemovie\.(org|cyou|com)$/i,
  /indexserver\.site$/i,
  /busycdn\.xyz$/i,
  /multicloudlinks\.com$/i,
  /gdflix\.(dev|dad|com)$/i,
  /hubcloud\.(lol|foo|com)$/i,
  /gdtot\.(dad|com|dev)$/i,
  /^gdlink\.dev$/i,
  /filepress\.(baby|com)$/i,
  /^multidownload\.website$/i,
  /^dr\d+\.multidownload\.website$/i,
];

const BROWSER_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';

function b64decode(str) {
  const std = str.replace(/-/g, '+').replace(/_/g, '/');
  const pad = std.length % 4 === 0 ? std : std + '='.repeat(4 - (std.length % 4));
  try { return atob(pad); } catch { return null; }
}

function jsonError(status, msg) {
  return new Response(JSON.stringify({ ok: false, error: msg }), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'access-control-allow-origin': '*',
      'cache-control': 'no-store',
    },
  });
}

export async function onRequest(context) {
  const { request, params } = context;
  const u = params?.u || new URL(request.url).searchParams.get('u');

  if (!u) return jsonError(400, 'Missing ?u= param');

  let targetUrl;
  if (/^[A-Za-z0-9_-]+$/.test(u)) targetUrl = b64decode(u);
  else targetUrl = decodeURIComponent(u);

  if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
    return jsonError(400, 'Invalid base64');
  }

  let hostname;
  try { hostname = new URL(targetUrl).hostname; }
  catch { return jsonError(400, 'Invalid URL'); }
  if (!ALLOWED_PROXY_HOSTS.some(re => re.test(hostname))) {
    return jsonError(403, 'Host not allowed: ' + hostname);
  }

  try {
    const upstream = await fetch(targetUrl, {
      method: request.method,
      headers: {
        'User-Agent': BROWSER_UA,
        'Referer': '',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      cf: { cacheTtl: 60, cacheEverything: false },
    });

    const headers = new Headers(upstream.headers);
    headers.set('access-control-allow-origin', '*');
    headers.set('access-control-allow-methods', 'GET, HEAD, OPTIONS');
    headers.delete('x-frame-options');
    headers.delete('content-security-policy');

    return new Response(upstream.body, { status: upstream.status, headers });
  } catch (e) {
    return jsonError(502, `Upstream fetch failed: ${e.message || e}`);
  }
}
